e, v, m = 3, 8, 90
print(e)
print(v)
print(m)

a = int(input("Введите число"))
s = input("Введите текст")
print(a)
print(s)