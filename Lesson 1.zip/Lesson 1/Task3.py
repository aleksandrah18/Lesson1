
n = input("Введите число: ")
n1 = n + n
n2 = n1 + n
summ = int(n)+int(n1)+int(n2)
print(summ)
